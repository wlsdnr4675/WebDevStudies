package soo.md.filesetting;

public class Path {
	public static final String FILE_STORE = "C:/SOO/store";
}
